using System;

namespace Microservices.Common.Exceptions
{
    /// <summary>
    /// Ошибка авторизации
    /// </summary>
    public class AuthorizationException : Exception
    {
    }
}