using System;

namespace Microservices.Common.Exceptions
{
    /// <summary>
    /// Сетевая ошибка
    /// </summary>
    public class ConnectionException : Exception
    {
    }
}