using System;

namespace Microservices.Common.Exceptions
{
    /// <summary>
    /// Ошибка запроса
    /// </summary>
    public class InvalidRequestException : Exception
    {
    }
}